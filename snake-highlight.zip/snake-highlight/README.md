# Snake highlight

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/EQXjOR](https://codepen.io/ainalem/pen/EQXjOR).

Slithering highlight in login form